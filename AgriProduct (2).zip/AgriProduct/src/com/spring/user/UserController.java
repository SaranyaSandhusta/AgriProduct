package com.spring.user;
import com.spring.*;

import antlr.collections.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class UserController {
 
	@Autowired
	private UserService userService;
	
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
	@RequestMapping("/signup")
	public String signup() {
		return "signup";
	}
	@RequestMapping("/shop")
	public String shop() {
		return "shop";
	}
	@RequestMapping("/store")
	public String store() {
		return "store";
	}
	@RequestMapping("/createUser")
	public String createUser(@RequestParam("userName")String name,@RequestParam("password")String password,@RequestParam("role")String role,@RequestParam("email")String email,@RequestParam("mobileNumber")String mobileNumber,@RequestParam("address")String address)
	{
		String[] arr=address.split(",");
		Address add=new Address(Integer.parseInt(arr[0]),arr[1],arr[2],arr[3],Integer.parseInt(arr[4]));
		User user=new User(name,password,role,email,mobileNumber,add);
		userService.saveUserObj(user);
		if(role.equals("owner"))
			return "redirect:shop.do";
		else
			return "index";		
	}
	@RequestMapping("/shopDetail")
	public String shopDetail(@RequestParam("shopName")String shopName,@RequestParam("address")String address)
	{
		String[] arr=address.split(",");
		Address add=new Address(Integer.parseInt(arr[0]),arr[1],arr[2],arr[3],Integer.parseInt(arr[4]));
		//Integer id=23;
		User user=userService.findId();
		Shop shop=new Shop(user,shopName,add);
		userService.saveShopDetail(shop);
		return "index";
	}
	@RequestMapping("/getAllUser" )
	public ModelAndView getAllUser()
	{
		return null;
		
	}

	@RequestMapping("/loginSuccess" )
	public String loginSuccess(@RequestParam("email")String email,@RequestParam("password")String password)
	{
	    User u=userService.checkUser(email,password);
	    		if(u==null)
	    			return "redirect:index.do";
	    		else if(u.getPassword().equals(password) && u.getRole().equals("owner") )
	    			return "redirect:store.do";
	    		else if(u.getPassword().equals(password) && u.getRole().equals("user") )
	    			return "redirect:index.do";
	    		else
	    			return "redirect:index.do";
	    			
		
	}
	
	
	
}
