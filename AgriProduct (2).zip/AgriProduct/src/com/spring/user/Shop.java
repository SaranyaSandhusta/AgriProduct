package com.spring.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;

@SuppressWarnings("serial")
@Entity
@Table(name="Shop")
public class Shop implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id; 
	
	@ManyToOne
	@ForeignKey(name="user")
	@Autowired
	  private User user;
	
	@Column(name="shopName")
	private String shopName;
	
	@OneToOne
	@ForeignKey(name="address")
	@Autowired
	private Address address;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user=user;
	}
	public String getShopName()
	{
		return shopName;
	}
	public void setShopeName(String shopName)
	{
		this.shopName=shopName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	Shop(){
		
	}
	public Shop(Integer id,User user,String shopName,Address address)
	{
		this.id=id;
		this.user=user;
		this.shopName=shopName;
		this.address=address;
	}
	public Shop(User user,String shopName,Address address)
	{
	    this.user=user;
		this.shopName=shopName;
		this.address=address;
	}
}
