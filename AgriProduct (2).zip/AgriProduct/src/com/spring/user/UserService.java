package com.spring.user;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.user.User;
import com.spring.user.UserService;

import antlr.collections.List;

@Service
public class UserService  {

     @Autowired
	SessionFactory sessionFactory;
	
     @Autowired
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
     @Autowired
	public SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
	
 @Transactional
	public void saveUserObj(User userObj) {
		Address address=userObj.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(userObj);
	}
 @Transactional
 public User checkUser(String email,String password)
 {
	 return (User)sessionFactory.getCurrentSession().createQuery("from User U where U.email=:email ").setString("email", email).uniqueResult();
 }
@Transactional
	public void saveShopDetail(Shop shop) {
	     //User user=shop.getUser();
		Address address=shop.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(shop);
	}
@Transactional
 public User findId()
 {
     User user =  (User) sessionFactory.getCurrentSession().createQuery("from User ORDER BY id DESC")
                  .setMaxResults(1).uniqueResult();
	return user;
	
 }
/*@Transactional
public Address getAllAddress(Integer doorno)
{
	 return (Address) sessionFactory.getCurrentSession().createQuery("from Address a where a.doorNo=:doorno AND a.").setInteger("doorno",doorno).uniqueResult();
}

*/
	
	
}
