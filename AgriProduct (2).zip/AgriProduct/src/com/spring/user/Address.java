package com.spring.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@SuppressWarnings("serial")
@Entity
@Table(name = "Address")
public class Address implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Integer id;
	@Column(name = "doorNo")
    private  Integer doorNo;
	
	@Column(name = "street")
    private String street;
	
	@Column(name = "area")
    private String area;
	
	@Column(name = "city")
    private String city;
	 
	@Column(name = "pincode")
    private Integer pincode;
	
	 public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;}
public Integer getDoorNo() {
	return doorNo;
}
public void setDoorNo(Integer doorNo) {
	this.doorNo = doorNo;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public Integer getPincode() {
	return pincode;
}
public void setPincode(Integer pincode) {
	this.pincode = pincode;
}
Address()
{
	
}
public Address(Integer doorNo, String street, String area, String city, Integer pincode) {
	this.doorNo = doorNo;
	this.street = street;
	this.area = area;
	this.city = city;
	this.pincode = pincode;
}
public Address(Integer id,Integer doorNo, String street, String area, String city, Integer pincode) {
	this.id=id;
	this.doorNo = doorNo;
	this.street = street;
	this.area = area;
	this.city = city;
	this.pincode = pincode;
}

}
